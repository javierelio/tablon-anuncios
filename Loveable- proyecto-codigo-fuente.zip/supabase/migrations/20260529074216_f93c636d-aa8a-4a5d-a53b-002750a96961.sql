
-- =========================
-- Enums
-- =========================
CREATE TYPE public.app_role AS ENUM ('dm', 'player');
CREATE TYPE public.notice_status AS ENUM ('available', 'taken', 'completed', 'archived');
CREATE TYPE public.prep_status AS ENUM ('idea', 'prepared', 'in_play', 'resolved', 'discarded');
CREATE TYPE public.danger_level AS ENUM ('trivial', 'low', 'moderate', 'high', 'deadly', 'unknown');
CREATE TYPE public.board_type AS ENUM ('faction', 'settlement', 'region', 'guild', 'rumor', 'tavern', 'authority', 'other');

-- =========================
-- Updated_at helper
-- =========================
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

-- =========================
-- profiles
-- =========================
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.profiles TO authenticated;
GRANT UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles readable by authenticated" ON public.profiles
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "users update own profile" ON public.profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id);
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================
-- user_roles + has_role
-- =========================
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "users see own roles" ON public.user_roles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- =========================
-- handle_new_user trigger
-- =========================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, display_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email,'@',1)));
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'player');
  RETURN NEW;
END;
$$;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- =========================
-- campaigns
-- =========================
CREATE TABLE public.campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  dm_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.campaigns TO authenticated;
GRANT ALL ON public.campaigns TO service_role;
ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_campaigns_updated BEFORE UPDATE ON public.campaigns
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================
-- campaign_members
-- =========================
CREATE TABLE public.campaign_members (
  campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  added_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (campaign_id, user_id)
);
GRANT SELECT, INSERT, DELETE ON public.campaign_members TO authenticated;
GRANT ALL ON public.campaign_members TO service_role;
ALTER TABLE public.campaign_members ENABLE ROW LEVEL SECURITY;

-- Helper: is user a member of (or DM of) a campaign
CREATE OR REPLACE FUNCTION public.is_campaign_member(_user_id UUID, _campaign_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.campaigns c WHERE c.id = _campaign_id AND c.dm_id = _user_id
  ) OR EXISTS (
    SELECT 1 FROM public.campaign_members m WHERE m.campaign_id = _campaign_id AND m.user_id = _user_id
  )
$$;

CREATE OR REPLACE FUNCTION public.is_campaign_dm(_user_id UUID, _campaign_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.campaigns c WHERE c.id = _campaign_id AND c.dm_id = _user_id)
$$;

-- campaigns policies (now that helper exists)
CREATE POLICY "members see campaign" ON public.campaigns
  FOR SELECT TO authenticated USING (public.is_campaign_member(auth.uid(), id));
CREATE POLICY "dm manages own campaign" ON public.campaigns
  FOR ALL TO authenticated USING (dm_id = auth.uid()) WITH CHECK (dm_id = auth.uid());

-- campaign_members policies
CREATE POLICY "members see roster" ON public.campaign_members
  FOR SELECT TO authenticated USING (public.is_campaign_member(auth.uid(), campaign_id));
CREATE POLICY "dm manages roster" ON public.campaign_members
  FOR ALL TO authenticated USING (public.is_campaign_dm(auth.uid(), campaign_id))
  WITH CHECK (public.is_campaign_dm(auth.uid(), campaign_id));

-- =========================
-- characters
-- =========================
CREATE TABLE public.characters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  concept TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.characters TO authenticated;
GRANT ALL ON public.characters TO service_role;
ALTER TABLE public.characters ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_characters_updated BEFORE UPDATE ON public.characters
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE POLICY "members see characters" ON public.characters
  FOR SELECT TO authenticated USING (public.is_campaign_member(auth.uid(), campaign_id));
CREATE POLICY "players manage own characters" ON public.characters
  FOR ALL TO authenticated
  USING (player_id = auth.uid() AND public.is_campaign_member(auth.uid(), campaign_id))
  WITH CHECK (player_id = auth.uid() AND public.is_campaign_member(auth.uid(), campaign_id));
CREATE POLICY "dm manages all characters" ON public.characters
  FOR ALL TO authenticated
  USING (public.is_campaign_dm(auth.uid(), campaign_id))
  WITH CHECK (public.is_campaign_dm(auth.uid(), campaign_id));

-- =========================
-- boards
-- =========================
CREATE TABLE public.boards (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  board_type public.board_type NOT NULL DEFAULT 'other',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.boards TO authenticated;
GRANT ALL ON public.boards TO service_role;
ALTER TABLE public.boards ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_boards_updated BEFORE UPDATE ON public.boards
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE POLICY "members see boards" ON public.boards
  FOR SELECT TO authenticated USING (public.is_campaign_member(auth.uid(), campaign_id));
CREATE POLICY "dm manages boards" ON public.boards
  FOR ALL TO authenticated
  USING (public.is_campaign_dm(auth.uid(), campaign_id))
  WITH CHECK (public.is_campaign_dm(auth.uid(), campaign_id));

-- =========================
-- notices
-- =========================
CREATE TABLE public.notices (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  board_id UUID NOT NULL REFERENCES public.boards(id) ON DELETE CASCADE,
  campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  -- public
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  fictional_author TEXT NOT NULL DEFAULT '',
  location TEXT NOT NULL DEFAULT '',
  visible_reward TEXT NOT NULL DEFAULT '',
  danger_level public.danger_level NOT NULL DEFAULT 'unknown',
  tags TEXT[] NOT NULL DEFAULT '{}',
  status public.notice_status NOT NULL DEFAULT 'available',
  in_game_date TEXT NOT NULL DEFAULT '',
  -- DM-only
  real_summary TEXT NOT NULL DEFAULT '',
  hook TEXT NOT NULL DEFAULT '',
  secret_info TEXT NOT NULL DEFAULT '',
  npcs TEXT NOT NULL DEFAULT '',
  locations TEXT NOT NULL DEFAULT '',
  complications TEXT NOT NULL DEFAULT '',
  real_reward TEXT NOT NULL DEFAULT '',
  ignore_consequences TEXT NOT NULL DEFAULT '',
  dm_notes TEXT NOT NULL DEFAULT '',
  prep_status public.prep_status NOT NULL DEFAULT 'idea',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notices TO authenticated;
GRANT ALL ON public.notices TO service_role;
ALTER TABLE public.notices ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_notices_updated BEFORE UPDATE ON public.notices
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- DM full access
CREATE POLICY "dm manages notices" ON public.notices
  FOR ALL TO authenticated
  USING (public.is_campaign_dm(auth.uid(), campaign_id))
  WITH CHECK (public.is_campaign_dm(auth.uid(), campaign_id));

-- Players: SELECT only non-archived rows. Private columns must NOT be exposed
-- to players in the app — enforce in server functions by selecting only the
-- public columns. RLS still allows row read so app can render the card.
CREATE POLICY "members see notices rows" ON public.notices
  FOR SELECT TO authenticated
  USING (
    public.is_campaign_member(auth.uid(), campaign_id)
    AND (public.is_campaign_dm(auth.uid(), campaign_id) OR status <> 'archived')
  );

CREATE INDEX idx_notices_board ON public.notices(board_id);
CREATE INDEX idx_notices_campaign ON public.notices(campaign_id);

-- View exposing only public fields for safe player reads
CREATE VIEW public.notices_public
WITH (security_invoker = true) AS
SELECT id, board_id, campaign_id, title, body, fictional_author, location,
       visible_reward, danger_level, tags, status, in_game_date,
       created_at, updated_at
FROM public.notices;
GRANT SELECT ON public.notices_public TO authenticated;

-- =========================
-- notice_pickups
-- =========================
CREATE TABLE public.notice_pickups (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  notice_id UUID NOT NULL REFERENCES public.notices(id) ON DELETE CASCADE,
  character_id UUID NOT NULL REFERENCES public.characters(id) ON DELETE CASCADE,
  player_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  campaign_id UUID NOT NULL REFERENCES public.campaigns(id) ON DELETE CASCADE,
  picked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  reverted_at TIMESTAMPTZ
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notice_pickups TO authenticated;
GRANT ALL ON public.notice_pickups TO service_role;
ALTER TABLE public.notice_pickups ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_pickups_notice ON public.notice_pickups(notice_id);
CREATE INDEX idx_pickups_character ON public.notice_pickups(character_id);

CREATE POLICY "members see pickups" ON public.notice_pickups
  FOR SELECT TO authenticated USING (public.is_campaign_member(auth.uid(), campaign_id));
CREATE POLICY "players insert own pickups" ON public.notice_pickups
  FOR INSERT TO authenticated
  WITH CHECK (
    player_id = auth.uid()
    AND public.is_campaign_member(auth.uid(), campaign_id)
    AND EXISTS (SELECT 1 FROM public.characters c WHERE c.id = character_id AND c.player_id = auth.uid())
  );
CREATE POLICY "dm manages pickups" ON public.notice_pickups
  FOR ALL TO authenticated
  USING (public.is_campaign_dm(auth.uid(), campaign_id))
  WITH CHECK (public.is_campaign_dm(auth.uid(), campaign_id));

-- =========================
-- notifications
-- =========================
CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  recipient_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  payload JSONB NOT NULL DEFAULT '{}'::jsonb,
  read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE INDEX idx_notifications_recipient ON public.notifications(recipient_id, read, created_at DESC);
CREATE POLICY "users see own notifications" ON public.notifications
  FOR SELECT TO authenticated USING (recipient_id = auth.uid());
CREATE POLICY "users update own notifications" ON public.notifications
  FOR UPDATE TO authenticated USING (recipient_id = auth.uid());
-- Inserts happen via SECURITY DEFINER trigger; no INSERT policy needed.

-- =========================
-- pickup -> notify DM + mark notice
-- =========================
CREATE OR REPLACE FUNCTION public.handle_notice_pickup()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  v_dm UUID;
  v_title TEXT;
  v_char TEXT;
BEGIN
  SELECT c.dm_id INTO v_dm FROM public.campaigns c WHERE c.id = NEW.campaign_id;
  SELECT n.title INTO v_title FROM public.notices n WHERE n.id = NEW.notice_id;
  SELECT ch.name INTO v_char FROM public.characters ch WHERE ch.id = NEW.character_id;

  UPDATE public.notices SET status = 'taken' WHERE id = NEW.notice_id AND status = 'available';

  INSERT INTO public.notifications (recipient_id, type, payload)
  VALUES (v_dm, 'notice_taken', jsonb_build_object(
    'notice_id', NEW.notice_id,
    'notice_title', v_title,
    'character_id', NEW.character_id,
    'character_name', v_char,
    'player_id', NEW.player_id,
    'campaign_id', NEW.campaign_id,
    'pickup_id', NEW.id
  ));
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_pickup_notify
AFTER INSERT ON public.notice_pickups
FOR EACH ROW EXECUTE FUNCTION public.handle_notice_pickup();

-- =========================
-- promote_to_dm helper (lets any signed-in user become DM of their own campaigns)
-- =========================
CREATE OR REPLACE FUNCTION public.ensure_dm_role()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.dm_id, 'dm')
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;
CREATE TRIGGER trg_campaign_dm_role
AFTER INSERT ON public.campaigns
FOR EACH ROW EXECUTE FUNCTION public.ensure_dm_role();
