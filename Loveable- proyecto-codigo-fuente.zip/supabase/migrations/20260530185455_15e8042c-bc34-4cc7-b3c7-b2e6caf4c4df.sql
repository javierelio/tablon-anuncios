
CREATE TABLE public.character_board_access (
  character_id UUID NOT NULL REFERENCES public.characters(id) ON DELETE CASCADE,
  board_id UUID NOT NULL REFERENCES public.boards(id) ON DELETE CASCADE,
  granted_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (character_id, board_id)
);
GRANT SELECT, INSERT, DELETE ON public.character_board_access TO authenticated;
GRANT ALL ON public.character_board_access TO service_role;
ALTER TABLE public.character_board_access ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.user_has_board_access(_user_id UUID, _board_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.character_board_access cba
    JOIN public.characters c ON c.id = cba.character_id
    WHERE cba.board_id = _board_id AND c.player_id = _user_id
  )
$$;

CREATE POLICY "members see own board access" ON public.character_board_access
  FOR SELECT TO authenticated USING (
    EXISTS (SELECT 1 FROM public.characters c WHERE c.id = character_id AND c.player_id = auth.uid())
    OR EXISTS (SELECT 1 FROM public.boards b WHERE b.id = board_id AND public.is_campaign_dm(auth.uid(), b.campaign_id))
  );

CREATE POLICY "dm manages board access" ON public.character_board_access
  FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.boards b WHERE b.id = board_id AND public.is_campaign_dm(auth.uid(), b.campaign_id)))
  WITH CHECK (EXISTS (SELECT 1 FROM public.boards b WHERE b.id = board_id AND public.is_campaign_dm(auth.uid(), b.campaign_id)));

DROP POLICY IF EXISTS "members see boards" ON public.boards;
CREATE POLICY "members see boards" ON public.boards
  FOR SELECT TO authenticated USING (
    public.is_campaign_dm(auth.uid(), campaign_id)
    OR public.user_has_board_access(auth.uid(), id)
  );

DROP POLICY IF EXISTS "members see notices rows" ON public.notices;
CREATE POLICY "members see notices rows" ON public.notices
  FOR SELECT TO authenticated USING (
    public.is_campaign_dm(auth.uid(), campaign_id)
    OR (status <> 'archived' AND public.user_has_board_access(auth.uid(), board_id))
  );
