-- Crear usuario DM de prueba: dm@tablon.test / tablon1234
DO $$
DECLARE v_id uuid;
BEGIN
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE email = 'dm@tablon.test') THEN
    v_id := gen_random_uuid();
    INSERT INTO auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
      created_at, updated_at, confirmation_token, email_change,
      email_change_token_new, recovery_token
    ) VALUES (
      '00000000-0000-0000-0000-000000000000', v_id,
      'authenticated', 'authenticated',
      'dm@tablon.test', crypt('tablon1234', gen_salt('bf')),
      now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      '{"display_name":"Maestro de Prueba"}'::jsonb,
      now(), now(), '', '', '', ''
    );
    INSERT INTO auth.identities (id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at)
    VALUES (gen_random_uuid(), v_id,
      jsonb_build_object('sub', v_id::text, 'email', 'dm@tablon.test', 'email_verified', true),
      'email', v_id::text, now(), now(), now());
  END IF;

  -- Promover a DM
  INSERT INTO public.user_roles (user_id, role)
  SELECT id, 'dm'::app_role FROM auth.users WHERE email = 'dm@tablon.test'
  AND NOT EXISTS (
    SELECT 1 FROM public.user_roles ur WHERE ur.user_id = auth.users.id AND ur.role = 'dm'
  );

  -- Campaña de ejemplo si no existe
  INSERT INTO public.campaigns (name, description, dm_id)
  SELECT 'Las Marcas del Oeste', 'Campaña de prueba para el tablón sombrío.', u.id
  FROM auth.users u
  WHERE u.email = 'dm@tablon.test'
  AND NOT EXISTS (SELECT 1 FROM public.campaigns c WHERE c.dm_id = u.id);
END $$;