export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      boards: {
        Row: {
          board_type: Database["public"]["Enums"]["board_type"]
          campaign_id: string
          created_at: string
          description: string
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          board_type?: Database["public"]["Enums"]["board_type"]
          campaign_id: string
          created_at?: string
          description?: string
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          board_type?: Database["public"]["Enums"]["board_type"]
          campaign_id?: string
          created_at?: string
          description?: string
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "boards_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
      campaign_members: {
        Row: {
          added_at: string
          campaign_id: string
          user_id: string
        }
        Insert: {
          added_at?: string
          campaign_id: string
          user_id: string
        }
        Update: {
          added_at?: string
          campaign_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "campaign_members_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
      campaigns: {
        Row: {
          created_at: string
          description: string
          dm_id: string
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string
          dm_id: string
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string
          dm_id?: string
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      character_board_access: {
        Row: {
          board_id: string
          character_id: string
          granted_at: string
        }
        Insert: {
          board_id: string
          character_id: string
          granted_at?: string
        }
        Update: {
          board_id?: string
          character_id?: string
          granted_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "character_board_access_board_id_fkey"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "character_board_access_character_id_fkey"
            columns: ["character_id"]
            isOneToOne: false
            referencedRelation: "characters"
            referencedColumns: ["id"]
          },
        ]
      }
      characters: {
        Row: {
          campaign_id: string
          concept: string
          created_at: string
          id: string
          name: string
          player_id: string
          updated_at: string
        }
        Insert: {
          campaign_id: string
          concept?: string
          created_at?: string
          id?: string
          name: string
          player_id: string
          updated_at?: string
        }
        Update: {
          campaign_id?: string
          concept?: string
          created_at?: string
          id?: string
          name?: string
          player_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "characters_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
      notice_pickups: {
        Row: {
          campaign_id: string
          character_id: string
          id: string
          notice_id: string
          picked_at: string
          player_id: string
          reverted_at: string | null
        }
        Insert: {
          campaign_id: string
          character_id: string
          id?: string
          notice_id: string
          picked_at?: string
          player_id: string
          reverted_at?: string | null
        }
        Update: {
          campaign_id?: string
          character_id?: string
          id?: string
          notice_id?: string
          picked_at?: string
          player_id?: string
          reverted_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notice_pickups_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notice_pickups_character_id_fkey"
            columns: ["character_id"]
            isOneToOne: false
            referencedRelation: "characters"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notice_pickups_notice_id_fkey"
            columns: ["notice_id"]
            isOneToOne: false
            referencedRelation: "notices"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notice_pickups_notice_id_fkey"
            columns: ["notice_id"]
            isOneToOne: false
            referencedRelation: "notices_public"
            referencedColumns: ["id"]
          },
        ]
      }
      notices: {
        Row: {
          board_id: string
          body: string
          campaign_id: string
          complications: string
          created_at: string
          danger_level: Database["public"]["Enums"]["danger_level"]
          dm_notes: string
          fictional_author: string
          hook: string
          id: string
          ignore_consequences: string
          in_game_date: string
          location: string
          locations: string
          npcs: string
          prep_status: Database["public"]["Enums"]["prep_status"]
          real_reward: string
          real_summary: string
          secret_info: string
          status: Database["public"]["Enums"]["notice_status"]
          tags: string[]
          title: string
          updated_at: string
          visible_reward: string
        }
        Insert: {
          board_id: string
          body?: string
          campaign_id: string
          complications?: string
          created_at?: string
          danger_level?: Database["public"]["Enums"]["danger_level"]
          dm_notes?: string
          fictional_author?: string
          hook?: string
          id?: string
          ignore_consequences?: string
          in_game_date?: string
          location?: string
          locations?: string
          npcs?: string
          prep_status?: Database["public"]["Enums"]["prep_status"]
          real_reward?: string
          real_summary?: string
          secret_info?: string
          status?: Database["public"]["Enums"]["notice_status"]
          tags?: string[]
          title: string
          updated_at?: string
          visible_reward?: string
        }
        Update: {
          board_id?: string
          body?: string
          campaign_id?: string
          complications?: string
          created_at?: string
          danger_level?: Database["public"]["Enums"]["danger_level"]
          dm_notes?: string
          fictional_author?: string
          hook?: string
          id?: string
          ignore_consequences?: string
          in_game_date?: string
          location?: string
          locations?: string
          npcs?: string
          prep_status?: Database["public"]["Enums"]["prep_status"]
          real_reward?: string
          real_summary?: string
          secret_info?: string
          status?: Database["public"]["Enums"]["notice_status"]
          tags?: string[]
          title?: string
          updated_at?: string
          visible_reward?: string
        }
        Relationships: [
          {
            foreignKeyName: "notices_board_id_fkey"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notices_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          payload: Json
          read: boolean
          recipient_id: string
          type: string
        }
        Insert: {
          created_at?: string
          id?: string
          payload?: Json
          read?: boolean
          recipient_id: string
          type: string
        }
        Update: {
          created_at?: string
          id?: string
          payload?: Json
          read?: boolean
          recipient_id?: string
          type?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string
          id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          display_name?: string
          id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          display_name?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      notices_public: {
        Row: {
          board_id: string | null
          body: string | null
          campaign_id: string | null
          created_at: string | null
          danger_level: Database["public"]["Enums"]["danger_level"] | null
          fictional_author: string | null
          id: string | null
          in_game_date: string | null
          location: string | null
          status: Database["public"]["Enums"]["notice_status"] | null
          tags: string[] | null
          title: string | null
          updated_at: string | null
          visible_reward: string | null
        }
        Insert: {
          board_id?: string | null
          body?: string | null
          campaign_id?: string | null
          created_at?: string | null
          danger_level?: Database["public"]["Enums"]["danger_level"] | null
          fictional_author?: string | null
          id?: string | null
          in_game_date?: string | null
          location?: string | null
          status?: Database["public"]["Enums"]["notice_status"] | null
          tags?: string[] | null
          title?: string | null
          updated_at?: string | null
          visible_reward?: string | null
        }
        Update: {
          board_id?: string | null
          body?: string | null
          campaign_id?: string | null
          created_at?: string | null
          danger_level?: Database["public"]["Enums"]["danger_level"] | null
          fictional_author?: string | null
          id?: string | null
          in_game_date?: string | null
          location?: string | null
          status?: Database["public"]["Enums"]["notice_status"] | null
          tags?: string[] | null
          title?: string | null
          updated_at?: string | null
          visible_reward?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notices_board_id_fkey"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notices_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_campaign_dm: {
        Args: { _campaign_id: string; _user_id: string }
        Returns: boolean
      }
      is_campaign_member: {
        Args: { _campaign_id: string; _user_id: string }
        Returns: boolean
      }
      user_has_board_access: {
        Args: { _board_id: string; _user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "dm" | "player"
      board_type:
        | "faction"
        | "settlement"
        | "region"
        | "guild"
        | "rumor"
        | "tavern"
        | "authority"
        | "other"
      danger_level:
        | "trivial"
        | "low"
        | "moderate"
        | "high"
        | "deadly"
        | "unknown"
      notice_status: "available" | "taken" | "completed" | "archived"
      prep_status: "idea" | "prepared" | "in_play" | "resolved" | "discarded"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["dm", "player"],
      board_type: [
        "faction",
        "settlement",
        "region",
        "guild",
        "rumor",
        "tavern",
        "authority",
        "other",
      ],
      danger_level: ["trivial", "low", "moderate", "high", "deadly", "unknown"],
      notice_status: ["available", "taken", "completed", "archived"],
      prep_status: ["idea", "prepared", "in_play", "resolved", "discarded"],
    },
  },
} as const
