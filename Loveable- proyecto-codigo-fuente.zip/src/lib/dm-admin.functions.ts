import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const USER_DOMAIN = "tablon.local";
const usernameSchema = z
  .string()
  .min(2)
  .max(40)
  .regex(/^[a-zA-Z0-9_.-]+$/, "Solo letras, números, _ . y -");

async function assertIsDm(userId: string) {
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "dm")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Solo el alguacil puede hacer esto.");
}

// ---------- Campaigns ----------
export const createCampaign = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        name: z.string().min(1).max(120),
        description: z.string().max(800).default(""),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const { data: row, error } = await supabase
      .from("campaigns")
      .insert({ name: data.name, description: data.description, dm_id: userId })
      .select("id, name, description")
      .single();
    if (error) throw new Error(error.message);
    // Make sure DM is also a member (so all member-scoped reads work without surprises)
    await supabaseAdmin
      .from("campaign_members")
      .insert({ campaign_id: row.id, user_id: userId })
      .select()
      .then(() => undefined, () => undefined);
    return row;
  });

// ---------- Users (players) ----------
export const listPlayers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertIsDm(context.userId);
    const { data: roles, error: rolesErr } = await supabaseAdmin
      .from("user_roles")
      .select("user_id")
      .eq("role", "player");
    if (rolesErr) throw new Error(rolesErr.message);
    const ids = (roles ?? []).map((r) => r.user_id);
    if (ids.length === 0) return [];
    const { data: profiles, error: profErr } = await supabaseAdmin
      .from("profiles")
      .select("id, display_name")
      .in("id", ids);
    if (profErr) throw new Error(profErr.message);
    return profiles ?? [];
  });

export const createPlayer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        username: usernameSchema,
        password: z.string().min(6).max(72),
        displayName: z.string().min(1).max(80),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    await assertIsDm(context.userId);
    const email = `${data.username.toLowerCase()}@${USER_DOMAIN}`;
    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email,
      password: data.password,
      email_confirm: true,
      user_metadata: { display_name: data.displayName },
    });
    if (error) throw new Error(error.message);
    const newId = created.user?.id;
    if (!newId) throw new Error("No se pudo crear el sello.");
    // handle_new_user trigger creates profile + player role, but display_name
    // may default to email prefix. Force it to the requested one.
    await supabaseAdmin
      .from("profiles")
      .update({ display_name: data.displayName })
      .eq("id", newId);
    return { id: newId, display_name: data.displayName, username: data.username };
  });

// ---------- Characters ----------
export const listCampaignCharacters = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ campaignId: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    await assertIsDm(context.userId);
    const { data: chars, error } = await supabaseAdmin
      .from("characters")
      .select("id, name, concept, player_id")
      .eq("campaign_id", data.campaignId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    const playerIds = Array.from(new Set((chars ?? []).map((c) => c.player_id)));
    const { data: profiles } = playerIds.length
      ? await supabaseAdmin.from("profiles").select("id, display_name").in("id", playerIds)
      : { data: [] as { id: string; display_name: string }[] };
    const nameById = new Map((profiles ?? []).map((p) => [p.id, p.display_name]));
    return (chars ?? []).map((c) => ({
      id: c.id,
      name: c.name,
      concept: c.concept,
      player_id: c.player_id,
      player_name: nameById.get(c.player_id) ?? "—",
    }));
  });

export const createCharacter = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        campaignId: z.string().uuid(),
        playerId: z.string().uuid(),
        name: z.string().min(1).max(120),
        concept: z.string().max(400).default(""),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    await assertIsDm(context.userId);
    // Make sure player is a campaign member so RLS-based reads work.
    await supabaseAdmin
      .from("campaign_members")
      .upsert({ campaign_id: data.campaignId, user_id: data.playerId }, { onConflict: "campaign_id,user_id" });
    const { data: row, error } = await supabaseAdmin
      .from("characters")
      .insert({
        campaign_id: data.campaignId,
        player_id: data.playerId,
        name: data.name,
        concept: data.concept,
      })
      .select("id, name, concept, player_id")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

// ---------- Character ↔ Board access ----------
export const listCharacterBoardAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ characterId: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    await assertIsDm(context.userId);
    const { data: rows, error } = await supabaseAdmin
      .from("character_board_access")
      .select("board_id")
      .eq("character_id", data.characterId);
    if (error) throw new Error(error.message);
    return (rows ?? []).map((r) => r.board_id);
  });

export const setCharacterBoardAccess = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        characterId: z.string().uuid(),
        boardId: z.string().uuid(),
        granted: z.boolean(),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    await assertIsDm(context.userId);
    if (data.granted) {
      const { error } = await supabaseAdmin
        .from("character_board_access")
        .upsert(
          { character_id: data.characterId, board_id: data.boardId },
          { onConflict: "character_id,board_id" },
        );
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabaseAdmin
        .from("character_board_access")
        .delete()
        .eq("character_id", data.characterId)
        .eq("board_id", data.boardId);
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });
