import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listAccessibleBoards = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data, error } = await supabase
      .from("boards")
      .select("id, name, description, board_type, campaign_id, campaigns(name)")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []).map((b) => ({
      id: b.id,
      name: b.name,
      description: b.description,
      board_type: b.board_type,
      campaign_id: b.campaign_id,
      campaign_name: (b.campaigns as { name: string } | null)?.name ?? "Campaña",
    }));
  });
