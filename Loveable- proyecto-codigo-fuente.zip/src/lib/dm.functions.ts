import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const listDmCampaigns = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("campaigns")
      .select("id, name, description")
      .eq("dm_id", userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const listCampaignBoards = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ campaignId: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { data: rows, error } = await supabase
      .from("boards")
      .select("id, name, board_type, description")
      .eq("campaign_id", data.campaignId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

const boardTypes = ["authority", "faction", "guild", "region", "rumor", "settlement", "tavern", "other"] as const;

export const createBoard = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        campaignId: z.string().uuid(),
        name: z.string().min(1).max(120),
        description: z.string().max(500).default(""),
        boardType: z.enum(boardTypes).default("other"),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { data: row, error } = await supabase
      .from("boards")
      .insert({
        campaign_id: data.campaignId,
        name: data.name,
        description: data.description,
        board_type: data.boardType,
      })
      .select("id, name, board_type, description")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });

const dangerLevels = ["unknown", "trivial", "low", "moderate", "high", "deadly"] as const;
const prepStatuses = ["idea", "prepared", "in_play", "resolved", "discarded"] as const;

export const listBoardNotices = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ boardId: z.string().uuid() }).parse(input))
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { data: rows, error } = await supabase
      .from("notices")
      .select("id, title, body, fictional_author, location, visible_reward, danger_level, tags, status, prep_status, created_at")
      .eq("board_id", data.boardId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return rows ?? [];
  });

export const createNotice = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z
      .object({
        boardId: z.string().uuid(),
        campaignId: z.string().uuid(),
        title: z.string().min(1).max(160),
        body: z.string().max(4000).default(""),
        fictional_author: z.string().max(120).default(""),
        location: z.string().max(160).default(""),
        visible_reward: z.string().max(160).default(""),
        danger_level: z.enum(dangerLevels).default("unknown"),
        in_game_date: z.string().max(80).default(""),
        tags: z.array(z.string().min(1).max(40)).max(12).default([]),
        // DM-private
        real_summary: z.string().max(4000).default(""),
        hook: z.string().max(2000).default(""),
        secret_info: z.string().max(4000).default(""),
        npcs: z.string().max(2000).default(""),
        locations: z.string().max(2000).default(""),
        complications: z.string().max(2000).default(""),
        real_reward: z.string().max(500).default(""),
        ignore_consequences: z.string().max(2000).default(""),
        dm_notes: z.string().max(4000).default(""),
        prep_status: z.enum(prepStatuses).default("idea"),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { boardId, campaignId, ...rest } = data;
    const { data: row, error } = await supabase
      .from("notices")
      .insert({ board_id: boardId, campaign_id: campaignId, ...rest })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return row;
  });
