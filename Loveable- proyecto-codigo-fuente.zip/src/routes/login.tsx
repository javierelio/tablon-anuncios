import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/login")({
  head: () => ({
    meta: [
      { title: "Entrar al Tablón — El Tablón Sombrío" },
      { name: "description", content: "Inicia sesión con el sello que te entregó el alguacil." },
    ],
  }),
  component: LoginPage,
});

const USER_DOMAIN = "tablon.local";

function usernameToEmail(input: string): string {
  const trimmed = input.trim().toLowerCase();
  if (trimmed.includes("@")) return trimmed;
  return `${trimmed}@${USER_DOMAIN}`;
}

function LoginPage() {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getUser().then(({ data }) => {
      if (data.user) navigate({ to: "/boards" });
    });
  }, [navigate]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!username.trim() || !password) return;
    setLoading(true);
    try {
      const email = usernameToEmail(username);
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      toast.success("Bienvenido de vuelta.");
      navigate({ to: "/boards" });
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : "El sello no encaja.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-planks flex items-center justify-center px-6 py-12">
      <div className="parchment torn w-full max-w-md p-10">
        <header className="text-center mb-8">
          <h1 className="text-3xl" style={{ color: "var(--ink)" }}>
            Sello de Acceso
          </h1>
          <p className="mt-2 text-sm italic" style={{ color: "var(--ink)", opacity: 0.7 }}>
            Identifícate ante el guardián del tablón con el sello que te entregó el alguacil.
          </p>
        </header>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            required
            autoComplete="username"
            placeholder="Nombre de sello"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full px-4 py-3 border focus:outline-none focus:ring-2"
            style={{ borderColor: "var(--ink)", color: "var(--ink)", background: "transparent" }}
          />
          <input
            type="password"
            required
            autoComplete="current-password"
            placeholder="Contraseña secreta"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-3 border focus:outline-none focus:ring-2"
            style={{ borderColor: "var(--ink)", color: "var(--ink)", background: "transparent" }}
          />
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-primary text-primary-foreground font-display tracking-widest uppercase text-sm border-2 border-double border-foreground/30 disabled:opacity-50"
          >
            {loading ? "..." : "Entrar"}
          </button>
        </form>

        <p className="mt-8 text-center text-xs italic" style={{ color: "var(--ink)", opacity: 0.7 }}>
          ¿No tienes sello? Pídele al alguacil que te forje uno.
        </p>

        <div
          className="mt-6 border-t pt-4 text-[0.7rem] space-y-2"
          style={{ borderColor: "var(--ink)", color: "var(--ink)", opacity: 0.75 }}
        >
          <p className="font-display uppercase tracking-widest text-center">
            Sellos de prueba
          </p>
          <div className="flex justify-between gap-4">
            <span>Alguacil (DM):</span>
            <span><code>dm</code> / <code>TablonSombrio#2026</code></span>
          </div>
          <div className="flex justify-between gap-4">
            <span>Jugador:</span>
            <span><code>jugador</code> / <code>JugadorSombrio#2026</code></span>
          </div>
        </div>
      </div>
    </main>
  );
}

