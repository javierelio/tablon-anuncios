import { createFileRoute, Link, redirect, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { listAccessibleBoards } from "@/lib/boards.functions";


export const Route = createFileRoute("/boards")({
  head: () => ({
    meta: [{ title: "Tablones — El Tablón Sombrío" }],
  }),
  beforeLoad: async () => {
    if (typeof window === "undefined") return;
    const { data, error } = await supabase.auth.getUser();
    // Solo redirigir cuando confirmamos que NO hay usuario.
    // Un fallo de red transitorio no debe expulsar al login (causa bucles).
    if (!error && !data.user) throw redirect({ to: "/login" });
  },
  component: BoardsPage,
});

function BoardsPage() {
  const fetchBoards = useServerFn(listAccessibleBoards);
  const navigate = useNavigate();
  const [displayName, setDisplayName] = useState<string>("");
  const [hasSession, setHasSession] = useState<boolean>(false);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      setHasSession(!!data.session);
      const name =
        (data.session?.user?.user_metadata?.display_name as string | undefined) ??
        data.session?.user?.email ??
        "";
      setDisplayName(name);
    });
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, session) => {
      setHasSession(!!session);
    });
    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const { data, isLoading, error } = useQuery({
    queryKey: ["accessible-boards"],
    queryFn: () => fetchBoards(),
    enabled: hasSession,
  });


  async function handleLogout() {
    await supabase.auth.signOut();
    toast.success("Hasta la próxima ronda.");
    navigate({ to: "/login" });
  }

  return (
    <main className="min-h-screen bg-planks">
      <header className="border-b border-foreground/20 bg-background/40 backdrop-blur">
        <div className="mx-auto max-w-6xl px-6 py-5 flex items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.3em]" style={{ color: "var(--gold)" }}>
              Por orden del alguacil
            </p>
            <h1 className="text-2xl md:text-3xl mt-1">El Tablón Sombrío</h1>
          </div>
          <div className="flex items-center gap-4 text-sm">
            {displayName && (
              <span className="hidden sm:inline italic text-muted-foreground">
                {displayName}
              </span>
            )}
            <button
              onClick={handleLogout}
              className="px-4 py-2 border border-foreground/30 font-display uppercase tracking-widest text-xs hover:bg-foreground/10"
            >
              Salir
            </button>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-6 py-12">
        <div className="mb-8 flex flex-wrap justify-center gap-3">
          <Link
            to="/dm"
            hash="campaigns"
            className="px-4 py-2 border-2 border-double border-foreground/40 font-display uppercase tracking-widest text-xs hover:bg-foreground/10"
            style={{ color: "var(--gold)" }}
          >
            ✶ Crear / editar crónica
          </Link>
          <Link
            to="/dm"
            hash="players"
            className="px-4 py-2 border-2 border-double border-foreground/40 font-display uppercase tracking-widest text-xs hover:bg-foreground/10"
            style={{ color: "var(--gold)" }}
          >
            ✶ Crear / editar jugadores
          </Link>
        </div>
        <div className="mb-10 text-center">
          <h2 className="text-3xl md:text-4xl">Tablones disponibles</h2>
          <div className="divider-ornament mx-auto mt-4 max-w-sm text-xs">
            <span>✦</span>
          </div>
          <p className="mt-3 text-sm italic text-muted-foreground">
            Acércate y lee los papeles clavados. Algunos aún huelen a lacre fresco.
          </p>
        </div>


        {isLoading && (
          <p className="text-center text-muted-foreground italic">Desenrollando pergaminos…</p>
        )}

        {error && (
          <p className="text-center" style={{ color: "var(--blood)" }}>
            No se pudieron leer los tablones: {(error as Error).message}
          </p>
        )}

        {!isLoading && !error && data && data.length === 0 && (
          <div className="parchment torn mx-auto max-w-xl p-10 text-center">
            <p style={{ color: "var(--ink)" }} className="italic">
              Aún no hay tablones colgados. El alguacil no ha clavado ningún papel.
            </p>
          </div>
        )}

        {!isLoading && data && data.length > 0 && (
          <ul className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {data.map((b) => (
              <li
                key={b.id}
                className="parchment torn p-7 opacity-95"
                title="El detalle del tablón estará disponible próximamente"
              >
                <p
                  className="text-[0.65rem] uppercase tracking-[0.25em] mb-2"
                  style={{ color: "var(--blood)" }}
                >
                  {b.campaign_name} · {b.board_type}
                </p>
                <h3 className="text-xl mb-2" style={{ color: "var(--ink)" }}>
                  {b.name}
                </h3>
                {b.description && (
                  <p
                    className="text-sm italic"
                    style={{ color: "var(--ink)", opacity: 0.75 }}
                  >
                    {b.description}
                  </p>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>
    </main>
  );
}
