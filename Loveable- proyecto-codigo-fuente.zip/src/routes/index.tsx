import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { useEffect } from "react";

export const Route = createFileRoute("/")({
  component: IndexRedirect,
});

function IndexRedirect() {
  const navigate = useNavigate();

  useEffect(() => {
    let mounted = true;

    supabase.auth.getUser().then(({ data }) => {
      if (!mounted) return;
      navigate({ to: data.user ? "/boards" : "/login", replace: true });
    });

    return () => {
      mounted = false;
    };
  }, [navigate]);

  return (
    <main className="min-h-screen bg-planks flex items-center justify-center px-6 text-center">
      <div className="parchment torn max-w-md p-8">
        <h1 className="text-2xl" style={{ color: "var(--ink)" }}>
          Abriendo el tablón…
        </h1>
        <p className="mt-3 text-sm italic" style={{ color: "var(--ink)", opacity: 0.72 }}>
          El guardián está comprobando tu sello.
        </p>
      </div>
    </main>
  );
}
