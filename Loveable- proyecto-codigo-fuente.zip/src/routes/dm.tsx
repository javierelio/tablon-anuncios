import { createFileRoute, Link, redirect, useLocation, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  createBoard,
  createNotice,
  listBoardNotices,
  listCampaignBoards,
  listDmCampaigns,
} from "@/lib/dm.functions";
import {
  createCampaign,
  createCharacter,
  createPlayer,
  listCampaignCharacters,
  listCharacterBoardAccess,
  listPlayers,
  setCharacterBoardAccess,
} from "@/lib/dm-admin.functions";

export const Route = createFileRoute("/dm")({
  head: () => ({ meta: [{ title: "Scriptorium — El Tablón Sombrío" }] }),
  beforeLoad: async () => {
    if (typeof window === "undefined") return;
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/login" });
  },
  component: DmPanel,
});

const boardTypeLabels: Record<string, string> = {
  authority: "Autoridad",
  faction: "Facción",
  guild: "Gremio",
  region: "Región",
  rumor: "Rumores",
  settlement: "Asentamiento",
  tavern: "Taberna",
  other: "Varios",
};

const dangerLabels: Record<string, string> = {
  unknown: "Desconocido",
  trivial: "Trivial",
  low: "Bajo",
  moderate: "Moderado",
  high: "Alto",
  deadly: "Mortal",
};

const prepLabels: Record<string, string> = {
  idea: "Idea",
  prepared: "Preparado",
  in_play: "En juego",
  resolved: "Resuelto",
  discarded: "Descartado",
};

type Tab = "campaigns" | "players" | "characters" | "boards" | "notices";

function DmPanel() {
  const navigate = useNavigate();
  const qc = useQueryClient();

  const fetchCampaigns = useServerFn(listDmCampaigns);
  const fetchBoards = useServerFn(listCampaignBoards);
  const fetchNotices = useServerFn(listBoardNotices);
  const createBoardFn = useServerFn(createBoard);
  const createNoticeFn = useServerFn(createNotice);

  const createCampaignFn = useServerFn(createCampaign);
  const createPlayerFn = useServerFn(createPlayer);
  const fetchPlayers = useServerFn(listPlayers);
  const fetchCharacters = useServerFn(listCampaignCharacters);
  const createCharacterFn = useServerFn(createCharacter);
  const fetchCharBoards = useServerFn(listCharacterBoardAccess);
  const toggleAccessFn = useServerFn(setCharacterBoardAccess);

  const campaignsQ = useQuery({ queryKey: ["dm-campaigns"], queryFn: () => fetchCampaigns() });
  const campaigns = campaignsQ.data ?? [];
  const [campaignId, setCampaignId] = useState<string>("");
  useEffect(() => {
    if (!campaignId && campaigns.length) setCampaignId(campaigns[0].id);
  }, [campaigns, campaignId]);

  const boardsQ = useQuery({
    queryKey: ["dm-boards", campaignId],
    queryFn: () => fetchBoards({ data: { campaignId } }),
    enabled: !!campaignId,
  });
  const boards = boardsQ.data ?? [];
  const [boardId, setBoardId] = useState<string>("");
  useEffect(() => {
    if (boards.length && !boards.find((b) => b.id === boardId)) {
      setBoardId(boards[0]?.id ?? "");
    }
    if (!boards.length) setBoardId("");
  }, [boards, boardId]);

  const noticesQ = useQuery({
    queryKey: ["dm-notices", boardId],
    queryFn: () => fetchNotices({ data: { boardId } }),
    enabled: !!boardId,
  });

  const playersQ = useQuery({ queryKey: ["dm-players"], queryFn: () => fetchPlayers() });
  const charactersQ = useQuery({
    queryKey: ["dm-characters", campaignId],
    queryFn: () => fetchCharacters({ data: { campaignId } }),
    enabled: !!campaignId,
  });

  const location = useLocation();
  const [tab, setTab] = useState<Tab>("campaigns");
  useEffect(() => {
    const h = location.hash.replace("#", "");
    if (["campaigns", "players", "characters", "boards", "notices"].includes(h)) {
      setTab(h as Tab);
    }
  }, [location.hash]);


  async function handleLogout() {
    await supabase.auth.signOut();
    navigate({ to: "/login" });
  }

  // ---- Mutations ----
  const [campForm, setCampForm] = useState({ name: "", description: "" });
  const campMut = useMutation({
    mutationFn: async () => createCampaignFn({ data: campForm }),
    onSuccess: (c) => {
      toast.success("Crónica abierta.");
      setCampForm({ name: "", description: "" });
      qc.invalidateQueries({ queryKey: ["dm-campaigns"] });
      if (c?.id) setCampaignId(c.id);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const [playerForm, setPlayerForm] = useState({ username: "", password: "", displayName: "" });
  const playerMut = useMutation({
    mutationFn: async () => createPlayerFn({ data: playerForm }),
    onSuccess: () => {
      toast.success(`Sello forjado para ${playerForm.displayName}.`);
      setPlayerForm({ username: "", password: "", displayName: "" });
      qc.invalidateQueries({ queryKey: ["dm-players"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const [charForm, setCharForm] = useState({ playerId: "", name: "", concept: "" });
  const charMut = useMutation({
    mutationFn: async () =>
      createCharacterFn({
        data: { campaignId, playerId: charForm.playerId, name: charForm.name, concept: charForm.concept },
      }),
    onSuccess: () => {
      toast.success("Personaje inscrito.");
      setCharForm({ playerId: "", name: "", concept: "" });
      qc.invalidateQueries({ queryKey: ["dm-characters", campaignId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  // Boards
  const [showBoardForm, setShowBoardForm] = useState(false);
  const [boardName, setBoardName] = useState("");
  const [boardDesc, setBoardDesc] = useState("");
  const [boardType, setBoardType] = useState<keyof typeof boardTypeLabels>("rumor");

  const boardMut = useMutation({
    mutationFn: async () =>
      createBoardFn({
        data: { campaignId, name: boardName, description: boardDesc, boardType: boardType as "rumor" },
      }),
    onSuccess: (b) => {
      toast.success("Tablón colgado en la pared.");
      setShowBoardForm(false);
      setBoardName("");
      setBoardDesc("");
      qc.invalidateQueries({ queryKey: ["dm-boards", campaignId] });
      qc.invalidateQueries({ queryKey: ["accessible-boards"] });
      if (b?.id) setBoardId(b.id);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  // Notices
  const empty = useMemo(
    () => ({
      title: "",
      body: "",
      fictional_author: "",
      location: "",
      visible_reward: "",
      in_game_date: "",
      danger_level: "unknown" as "unknown" | "trivial" | "low" | "moderate" | "high" | "deadly",
      tagsRaw: "",
      real_summary: "",
      hook: "",
      secret_info: "",
      npcs: "",
      locations: "",
      complications: "",
      real_reward: "",
      ignore_consequences: "",
      dm_notes: "",
      prep_status: "idea" as "idea" | "prepared" | "in_play" | "resolved" | "discarded",
    }),
    [],
  );
  const [form, setForm] = useState(empty);
  const set = <K extends keyof typeof empty>(k: K, v: (typeof empty)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const noticeMut = useMutation({
    mutationFn: async () => {
      const tags = form.tagsRaw
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean)
        .slice(0, 12);
      return createNoticeFn({
        data: {
          boardId,
          campaignId,
          title: form.title,
          body: form.body,
          fictional_author: form.fictional_author,
          location: form.location,
          visible_reward: form.visible_reward,
          in_game_date: form.in_game_date,
          danger_level: form.danger_level,
          tags,
          real_summary: form.real_summary,
          hook: form.hook,
          secret_info: form.secret_info,
          npcs: form.npcs,
          locations: form.locations,
          complications: form.complications,
          real_reward: form.real_reward,
          ignore_consequences: form.ignore_consequences,
          dm_notes: form.dm_notes,
          prep_status: form.prep_status,
        },
      });
    },
    onSuccess: () => {
      toast.success("Pergamino clavado en el tablón.");
      setForm(empty);
      qc.invalidateQueries({ queryKey: ["dm-notices", boardId] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <main className="min-h-screen bg-planks pb-24">
      <header className="border-b border-foreground/20 bg-background/40 backdrop-blur">
        <div className="mx-auto max-w-6xl px-6 py-5 flex items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.3em]" style={{ color: "var(--gold)" }}>
              Scriptorium del alguacil
            </p>
            <h1 className="text-2xl md:text-3xl mt-1">Gobernar el tablón</h1>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <Link
              to="/boards"
              className="px-4 py-2 border border-foreground/30 font-display uppercase tracking-widest hover:bg-foreground/10"
            >
              Tablones
            </Link>
            <button
              onClick={handleLogout}
              className="px-4 py-2 border border-foreground/30 font-display uppercase tracking-widest hover:bg-foreground/10"
            >
              Salir
            </button>
          </div>
        </div>
        <nav className="mx-auto max-w-6xl px-6 pb-4 flex flex-wrap gap-2 text-xs">
          {([
            ["campaigns", "Crónicas"],
            ["players", "Jugadores"],
            ["characters", "Personajes y accesos"],
            ["boards", "Tablones"],
            ["notices", "Pergaminos"],
          ] as [Tab, string][]).map(([k, label]) => (
            <button
              key={k}
              onClick={() => setTab(k)}
              className={`px-3 py-2 border font-display uppercase tracking-widest ${
                tab === k ? "bg-foreground/15 border-foreground/60" : "border-foreground/25 hover:bg-foreground/10"
              }`}
            >
              {label}
            </button>
          ))}
        </nav>
      </header>

      <section className="mx-auto max-w-6xl px-6 py-10 space-y-10">
        {/* Active campaign selector (visible for context-dependent tabs) */}
        {tab !== "campaigns" && tab !== "players" && (
          <Field label="Crónica activa">
            {campaigns.length === 0 ? (
              <p className="italic text-muted-foreground text-sm">Crea primero una crónica.</p>
            ) : (
              <select
                value={campaignId}
                onChange={(e) => setCampaignId(e.target.value)}
                className="w-full max-w-md px-3 py-2 bg-background/40 border border-foreground/30"
              >
                {campaigns.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            )}
          </Field>
        )}

        {/* CAMPAIGNS */}
        {tab === "campaigns" && (
          <div className="grid gap-6 md:grid-cols-2">
            <div className="parchment torn p-6 space-y-4" style={{ color: "var(--ink)" }}>
              <h2 className="text-xl">Abrir una nueva crónica</h2>
              <Input label="Nombre" value={campForm.name} onChange={(v) => setCampForm((f) => ({ ...f, name: v }))} dark />
              <Textarea
                label="Descripción"
                value={campForm.description}
                onChange={(v) => setCampForm((f) => ({ ...f, description: v }))}
                dark
                rows={3}
              />
              <button
                onClick={() => campMut.mutate()}
                disabled={!campForm.name || campMut.isPending}
                className="px-5 py-2 bg-primary text-primary-foreground font-display uppercase tracking-widest text-xs border-2 border-double border-foreground/30 disabled:opacity-50"
              >
                {campMut.isPending ? "Abriendo…" : "Abrir crónica"}
              </button>
            </div>
            <div>
              <h2 className="text-xl mb-3">Tus crónicas</h2>
              <ul className="space-y-2">
                {campaigns.map((c) => (
                  <li key={c.id} className="border border-foreground/20 px-4 py-3">
                    <p className="font-display tracking-widest uppercase text-sm">{c.name}</p>
                    {c.description && (
                      <p className="text-xs italic opacity-70 mt-1">{c.description}</p>
                    )}
                  </li>
                ))}
                {campaigns.length === 0 && (
                  <p className="italic text-muted-foreground text-sm">Aún no has abierto ninguna.</p>
                )}
              </ul>
            </div>
          </div>
        )}

        {/* PLAYERS */}
        {tab === "players" && (
          <div className="grid gap-6 md:grid-cols-2">
            <div className="parchment torn p-6 space-y-4" style={{ color: "var(--ink)" }}>
              <h2 className="text-xl">Forjar un sello (nuevo jugador)</h2>
              <p className="text-xs italic" style={{ color: "var(--ink)", opacity: 0.7 }}>
                El jugador entrará usando el nombre de sello y la contraseña que tú elijas.
                No hace falta correo.
              </p>
              <Input
                label="Nombre conocido"
                value={playerForm.displayName}
                onChange={(v) => setPlayerForm((f) => ({ ...f, displayName: v }))}
                dark
              />
              <Input
                label="Nombre de sello (sin espacios)"
                value={playerForm.username}
                onChange={(v) => setPlayerForm((f) => ({ ...f, username: v.replace(/\s+/g, "").toLowerCase() }))}
                dark
              />
              <Input
                label="Contraseña inicial"
                value={playerForm.password}
                onChange={(v) => setPlayerForm((f) => ({ ...f, password: v }))}
                dark
              />
              <button
                onClick={() => playerMut.mutate()}
                disabled={
                  !playerForm.username ||
                  !playerForm.displayName ||
                  playerForm.password.length < 6 ||
                  playerMut.isPending
                }
                className="px-5 py-2 bg-primary text-primary-foreground font-display uppercase tracking-widest text-xs border-2 border-double border-foreground/30 disabled:opacity-50"
              >
                {playerMut.isPending ? "Sellando…" : "Forjar sello"}
              </button>
            </div>
            <div>
              <h2 className="text-xl mb-3">Jugadores registrados</h2>
              <ul className="space-y-2">
                {(playersQ.data ?? []).map((p) => (
                  <li key={p.id} className="border border-foreground/20 px-4 py-2">
                    <p className="font-display uppercase tracking-widest text-sm">{p.display_name}</p>
                  </li>
                ))}
                {playersQ.data?.length === 0 && (
                  <p className="italic text-muted-foreground text-sm">Aún no hay jugadores.</p>
                )}
              </ul>
            </div>
          </div>
        )}

        {/* CHARACTERS */}
        {tab === "characters" && campaignId && (
          <div className="space-y-8">
            <div className="parchment torn p-6 space-y-4" style={{ color: "var(--ink)" }}>
              <h2 className="text-xl">Inscribir un personaje en esta crónica</h2>
              <DarkField label="Jugador">
                <select
                  value={charForm.playerId}
                  onChange={(e) => setCharForm((f) => ({ ...f, playerId: e.target.value }))}
                  className="w-full px-3 py-2 border"
                  style={{ borderColor: "var(--ink)", background: "transparent", color: "var(--ink)" }}
                >
                  <option value="">— Elige jugador —</option>
                  {(playersQ.data ?? []).map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.display_name}
                    </option>
                  ))}
                </select>
              </DarkField>
              <Input label="Nombre del personaje" value={charForm.name} onChange={(v) => setCharForm((f) => ({ ...f, name: v }))} dark />
              <Textarea
                label="Concepto / breve descripción"
                value={charForm.concept}
                onChange={(v) => setCharForm((f) => ({ ...f, concept: v }))}
                dark
                rows={3}
              />
              <button
                onClick={() => charMut.mutate()}
                disabled={!charForm.playerId || !charForm.name || charMut.isPending}
                className="px-5 py-2 bg-primary text-primary-foreground font-display uppercase tracking-widest text-xs border-2 border-double border-foreground/30 disabled:opacity-50"
              >
                {charMut.isPending ? "Inscribiendo…" : "Inscribir personaje"}
              </button>
            </div>

            <div>
              <h2 className="text-xl mb-3">Personajes y tablones a los que tienen acceso</h2>
              {charactersQ.data?.length === 0 && (
                <p className="italic text-muted-foreground text-sm">Aún no hay personajes inscritos.</p>
              )}
              <ul className="space-y-4">
                {(charactersQ.data ?? []).map((c) => (
                  <CharacterAccessRow
                    key={c.id}
                    character={c}
                    boards={boards}
                    fetchCharBoards={fetchCharBoards}
                    toggleAccessFn={toggleAccessFn}
                  />
                ))}
              </ul>
            </div>
          </div>
        )}

        {/* BOARDS */}
        {tab === "boards" && campaignId && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl">Tablones de esta crónica</h2>
              <button
                onClick={() => setShowBoardForm((s) => !s)}
                className="px-3 py-2 border border-foreground/30 font-display uppercase tracking-widest text-xs hover:bg-foreground/10"
              >
                {showBoardForm ? "Cerrar" : "+ Nuevo tablón"}
              </button>
            </div>

            {showBoardForm && (
              <div className="parchment torn p-6 max-w-2xl space-y-4" style={{ color: "var(--ink)" }}>
                <Input label="Nombre" value={boardName} onChange={setBoardName} dark />
                <Input label="Descripción" value={boardDesc} onChange={setBoardDesc} dark />
                <DarkField label="Tipo">
                  <select
                    value={boardType}
                    onChange={(e) => setBoardType(e.target.value as typeof boardType)}
                    className="w-full px-3 py-2 border"
                    style={{ borderColor: "var(--ink)", background: "transparent", color: "var(--ink)" }}
                  >
                    {Object.entries(boardTypeLabels).map(([k, v]) => (
                      <option key={k} value={k}>
                        {v}
                      </option>
                    ))}
                  </select>
                </DarkField>
                <button
                  onClick={() => boardMut.mutate()}
                  disabled={!boardName || boardMut.isPending}
                  className="px-5 py-2 bg-primary text-primary-foreground font-display uppercase tracking-widest text-xs border-2 border-double border-foreground/30 disabled:opacity-50"
                >
                  {boardMut.isPending ? "Clavando…" : "Colgar tablón"}
                </button>
              </div>
            )}

            <ul className="grid gap-3 md:grid-cols-2">
              {boards.map((b) => (
                <li key={b.id} className="border border-foreground/20 px-4 py-3">
                  <p className="text-[0.6rem] uppercase tracking-[0.25em]" style={{ color: "var(--gold)" }}>
                    {boardTypeLabels[b.board_type] ?? b.board_type}
                  </p>
                  <p className="font-display uppercase tracking-widest text-sm mt-1">{b.name}</p>
                  {b.description && <p className="text-xs italic opacity-70 mt-1">{b.description}</p>}
                </li>
              ))}
              {boards.length === 0 && (
                <p className="italic text-muted-foreground text-sm">No hay tablones aún.</p>
              )}
            </ul>
          </div>
        )}

        {/* NOTICES */}
        {tab === "notices" && campaignId && (
          <div className="space-y-8">
            <Field label="Tablón">
              <select
                value={boardId}
                onChange={(e) => setBoardId(e.target.value)}
                className="w-full max-w-md px-3 py-2 bg-background/40 border border-foreground/30"
                disabled={!boards.length}
              >
                {boards.length === 0 && <option value="">— Sin tablones —</option>}
                {boards.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name} · {boardTypeLabels[b.board_type] ?? b.board_type}
                  </option>
                ))}
              </select>
            </Field>

            {boardId && (
              <div className="parchment torn p-8 space-y-6" style={{ color: "var(--ink)" }}>
                <header>
                  <p className="text-[0.65rem] uppercase tracking-[0.3em]" style={{ color: "var(--blood)" }}>
                    Nuevo pergamino
                  </p>
                  <h2 className="text-2xl mt-1">Redactar anuncio</h2>
                </header>

                <section className="space-y-4">
                  <SubTitle>Lo que verán los jugadores</SubTitle>
                  <Input label="Título" value={form.title} onChange={(v) => set("title", v)} dark />
                  <Textarea label="Cuerpo del anuncio" value={form.body} onChange={(v) => set("body", v)} dark rows={5} />
                  <div className="grid gap-4 md:grid-cols-2">
                    <Input label="Firmado por" value={form.fictional_author} onChange={(v) => set("fictional_author", v)} dark />
                    <Input label="Lugar" value={form.location} onChange={(v) => set("location", v)} dark />
                    <Input label="Recompensa visible" value={form.visible_reward} onChange={(v) => set("visible_reward", v)} dark />
                    <Input label="Fecha (in-game)" value={form.in_game_date} onChange={(v) => set("in_game_date", v)} dark />
                    <DarkField label="Peligro">
                      <select
                        value={form.danger_level}
                        onChange={(e) => set("danger_level", e.target.value as typeof form.danger_level)}
                        className="w-full px-3 py-2 border"
                        style={{ borderColor: "var(--ink)", background: "transparent", color: "var(--ink)" }}
                      >
                        {Object.entries(dangerLabels).map(([k, v]) => (
                          <option key={k} value={k}>
                            {v}
                          </option>
                        ))}
                      </select>
                    </DarkField>
                    <Input label="Etiquetas (separadas por coma)" value={form.tagsRaw} onChange={(v) => set("tagsRaw", v)} dark />
                  </div>
                </section>

                <div className="divider-ornament text-xs"><span>✦ secreto del DM ✦</span></div>

                <section className="space-y-4">
                  <SubTitle>Notas privadas (solo el alguacil)</SubTitle>
                  <Textarea label="Resumen real" value={form.real_summary} onChange={(v) => set("real_summary", v)} dark rows={3} />
                  <Textarea label="Gancho" value={form.hook} onChange={(v) => set("hook", v)} dark rows={2} />
                  <Textarea label="Información oculta" value={form.secret_info} onChange={(v) => set("secret_info", v)} dark rows={3} />
                  <div className="grid gap-4 md:grid-cols-2">
                    <Textarea label="PNJs" value={form.npcs} onChange={(v) => set("npcs", v)} dark rows={3} />
                    <Textarea label="Localizaciones" value={form.locations} onChange={(v) => set("locations", v)} dark rows={3} />
                    <Textarea label="Complicaciones" value={form.complications} onChange={(v) => set("complications", v)} dark rows={3} />
                    <Textarea label="Consecuencias si lo ignoran" value={form.ignore_consequences} onChange={(v) => set("ignore_consequences", v)} dark rows={3} />
                    <Input label="Recompensa real" value={form.real_reward} onChange={(v) => set("real_reward", v)} dark />
                    <DarkField label="Estado de preparación">
                      <select
                        value={form.prep_status}
                        onChange={(e) => set("prep_status", e.target.value as typeof form.prep_status)}
                        className="w-full px-3 py-2 border"
                        style={{ borderColor: "var(--ink)", background: "transparent", color: "var(--ink)" }}
                      >
                        {Object.entries(prepLabels).map(([k, v]) => (
                          <option key={k} value={k}>
                            {v}
                          </option>
                        ))}
                      </select>
                    </DarkField>
                  </div>
                  <Textarea label="Notas del alguacil" value={form.dm_notes} onChange={(v) => set("dm_notes", v)} dark rows={3} />
                </section>

                <div className="flex justify-end">
                  <button
                    onClick={() => noticeMut.mutate()}
                    disabled={!form.title || noticeMut.isPending}
                    className="px-6 py-3 bg-primary text-primary-foreground font-display uppercase tracking-widest text-xs border-2 border-double border-foreground/30 disabled:opacity-50"
                  >
                    {noticeMut.isPending ? "Sellando…" : "Clavar al tablón"}
                  </button>
                </div>
              </div>
            )}

            {boardId && (
              <section className="space-y-4">
                <h2 className="text-xl">Pergaminos en este tablón</h2>
                {noticesQ.isLoading && <p className="italic text-muted-foreground text-sm">Cargando…</p>}
                {noticesQ.data && noticesQ.data.length === 0 && (
                  <p className="italic text-muted-foreground text-sm">Aún no hay pergaminos.</p>
                )}
                <ul className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {(noticesQ.data ?? []).map((n) => (
                    <li key={n.id} className="parchment torn p-5" style={{ color: "var(--ink)" }}>
                      <p className="text-[0.6rem] uppercase tracking-[0.25em]" style={{ color: "var(--blood)" }}>
                        {dangerLabels[n.danger_level] ?? n.danger_level} · {n.status}
                      </p>
                      <h3 className="text-lg mt-1" style={{ color: "var(--ink)" }}>{n.title}</h3>
                      {n.fictional_author && (
                        <p className="text-xs italic opacity-70">— {n.fictional_author}</p>
                      )}
                      {n.body && <p className="text-sm mt-2 line-clamp-4">{n.body}</p>}
                    </li>
                  ))}
                </ul>
              </section>
            )}
          </div>
        )}
      </section>
    </main>
  );
}

function CharacterAccessRow({
  character,
  boards,
  fetchCharBoards,
  toggleAccessFn,
}: {
  character: { id: string; name: string; concept: string; player_name: string };
  boards: { id: string; name: string; board_type: string }[];
  fetchCharBoards: (args: { data: { characterId: string } }) => Promise<string[]>;
  toggleAccessFn: (args: { data: { characterId: string; boardId: string; granted: boolean } }) => Promise<{ ok: boolean }>;
}) {
  const qc = useQueryClient();
  const accessQ = useQuery({
    queryKey: ["char-board-access", character.id],
    queryFn: () => fetchCharBoards({ data: { characterId: character.id } }),
  });
  const accessSet = new Set(accessQ.data ?? []);
  const toggle = useMutation({
    mutationFn: async (args: { boardId: string; granted: boolean }) =>
      toggleAccessFn({ data: { characterId: character.id, ...args } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["char-board-access", character.id] });
      qc.invalidateQueries({ queryKey: ["accessible-boards"] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <li className="border border-foreground/20 p-4 space-y-3">
      <div>
        <p className="font-display uppercase tracking-widest text-sm">
          {character.name}{" "}
          <span className="text-xs opacity-60">· {character.player_name}</span>
        </p>
        {character.concept && (
          <p className="text-xs italic opacity-70 mt-1">{character.concept}</p>
        )}
      </div>
      <div className="flex flex-wrap gap-2">
        {boards.length === 0 && (
          <p className="text-xs italic text-muted-foreground">No hay tablones en esta crónica.</p>
        )}
        {boards.map((b) => {
          const granted = accessSet.has(b.id);
          return (
            <button
              key={b.id}
              onClick={() => toggle.mutate({ boardId: b.id, granted: !granted })}
              disabled={toggle.isPending || accessQ.isLoading}
              className={`px-3 py-1 text-xs border font-display uppercase tracking-widest ${
                granted
                  ? "bg-primary text-primary-foreground border-foreground/40"
                  : "border-foreground/30 hover:bg-foreground/10"
              }`}
              title={granted ? "Acceso concedido" : "Sin acceso"}
            >
              {b.name}
            </button>
          );
        })}
      </div>
    </li>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-[0.65rem] uppercase tracking-[0.3em] block mb-2" style={{ color: "var(--gold)" }}>
        {label}
      </span>
      {children}
    </label>
  );
}

function DarkField({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span
        className="text-[0.65rem] uppercase tracking-[0.3em] block mb-2"
        style={{ color: "var(--blood)" }}
      >
        {label}
      </span>
      {children}
    </label>
  );
}

function SubTitle({ children }: { children: React.ReactNode }) {
  return (
    <h3 className="text-sm uppercase tracking-[0.3em]" style={{ color: "var(--blood)" }}>
      {children}
    </h3>
  );
}

function Input({
  label,
  value,
  onChange,
  dark,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  dark?: boolean;
}) {
  return (
    <DarkField label={label}>
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full px-3 py-2 border"
        style={
          dark
            ? { borderColor: "var(--ink)", background: "transparent", color: "var(--ink)" }
            : undefined
        }
      />
    </DarkField>
  );
}

function Textarea({
  label,
  value,
  onChange,
  rows = 3,
  dark,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  rows?: number;
  dark?: boolean;
}) {
  return (
    <DarkField label={label}>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={rows}
        className="w-full px-3 py-2 border resize-y"
        style={
          dark
            ? { borderColor: "var(--ink)", background: "transparent", color: "var(--ink)" }
            : undefined
        }
      />
    </DarkField>
  );
}
